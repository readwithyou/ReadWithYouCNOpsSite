<template>
  <div class="content">
    <div class="md-layout">
      <div class="md-layout-item md-medium-size-100 md-size-100">
        <teacher-form data-background-color="purple">
        </teacher-form>
      </div>
    </div>
  </div>
</template>
<script>
import {
  TeacherForm
} from 'pages'

export default{
  components: {
      TeacherForm
  }
}
</script>
