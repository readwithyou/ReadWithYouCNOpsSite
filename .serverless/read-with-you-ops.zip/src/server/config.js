module.exports = {
    'secret': 'da3057da-82df-4fbf-8dc2-69b41b901570'
};